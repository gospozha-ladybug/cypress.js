describe('Проверка авторизации', function () {

   it('Верный логин и верный пароль', function () {
        cy.visit('https://login.qa.studio/'); // Зашли на сайт
        cy.get('#forgotEmailButton').should('have.css', 'color', 'rgb(0, 85, 152)'); // цвет кнопки смотрю
        cy.get('#mail').type('german@dolnikov.ru'); // правильный логин
        cy.get('#pass').type('qa_one_love1'); // правильный пароль
        cy.get('#loginButton').click(); // нажала войти
        cy.get('#messageHeader').contains('Авторизация прошла успешно'); // проверяю, что текст
        cy.get('#messageHeader').should('be.visible'); // текст виден пользователю
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // есть крестик
        
    })


    it('Верный логин и неверный пароль', function () {
        cy.visit('https://login.qa.studio/'); // Зашли на сайт
        cy.get('#forgotEmailButton').should('have.css', 'color', 'rgb(0, 85, 152)'); // цвет кнопки смотрю
        cy.get('#mail').type('german@dolnikov.ru'); // правильный логин
        cy.get('#pass').type('qa_one_love7'); // неправильный пароль
        cy.get('#loginButton').click(); // нажала войти
        cy.get('#messageHeader').contains('Такого логина или пароля нет'); // проверяю, что текст
        cy.get('#messageHeader').should('be.visible'); // текст виден пользователю
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // есть крестик
        
    })

     it('Неверный логин и верный пароль', function () {
        cy.visit('https://login.qa.studio/'); // Зашли на сайт
        cy.get('#forgotEmailButton').should('have.css', 'color', 'rgb(0, 85, 152)'); // цвет кнопки смотрю
        cy.get('#mail').type('german@olnikov.ru'); // неправильный логин
        cy.get('#pass').type('qa_one_love1'); // правильный пароль
        cy.get('#loginButton').click(); // нажала войти
        cy.get('#messageHeader').contains('Такого логина или пароля нет'); // проверяю, что текст
        cy.get('#messageHeader').should('be.visible'); // текст виден пользователю
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // есть крестик
        
    })

     it('Проверка, что в логине есть @', function () {
        cy.visit('https://login.qa.studio/'); // Зашли на сайт
        cy.get('#forgotEmailButton').should('have.css', 'color', 'rgb(0, 85, 152)'); // цвет кнопки смотрю
        cy.get('#mail').type('germandolnikov.ru'); // ввела логин без @
        cy.get('#pass').type('qa_one_love1'); // правильный пароль
        cy.get('#loginButton').click(); // нажала войти
        cy.get('#messageHeader').contains('Нужно исправить проблему валидации'); // проверяю, что текст
        cy.get('#messageHeader').should('be.visible'); // текст виден пользователю
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // есть крестик
        
    })

    it('Проверка восстановления пароля', function () {
        cy.visit('https://login.qa.studio/'); // Зашли на сайт
        cy.get('#forgotEmailButton').should('have.css', 'color', 'rgb(0, 85, 152)'); // цвет кнопки смотрю
        cy.get('#forgotEmailButton').click(); // нажала кнопку забыли пароль
        cy.get('#mailForgot').type('german@dolnikov.ru'); // ввела правильный логин
        cy.get('#restoreEmailButton').click(); // нажала кнопку отправить код
        cy.get('#messageHeader').contains('Успешно отправили пароль на e-mail'); // проверяю, что текст
        cy.get('#messageHeader').should('be.visible'); // текст виден пользователю
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // есть крестик
        
    })

    it('Приведение к строчным буквам в логине', function () {
        cy.visit('https://login.qa.studio/'); // Зашли на сайт
        cy.get('#forgotEmailButton').should('have.css', 'color', 'rgb(0, 85, 152)'); // цвет кнопки смотрю
        cy.get('#mail').type('GerMan@Dolnikov.ru'); //  логин со строчными и заглавными буквами
        cy.get('#pass').type('qa_one_love1'); // правильный пароль
        cy.get('#loginButton').click(); // нажала войти
        cy.get('#messageHeader').contains('Авторизация прошла успешно'); // проверяю, что текст
        cy.get('#messageHeader').should('be.visible'); // текст виден пользователю
        cy.get('#exitMessageButton > .exitIcon').should('be.visible'); // есть крестик
        
    })

})


